package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;

public class MainMenu implements Screen {
    private final Start app;
    OrthographicCamera camera;
    Texture backgroundimg;
    private Stage stage;
    Texture startimg;
    Texture endimg;

    BitmapFont font;
    public void create(){
        Gdx.input.setInputProcessor(stage);
    }
    public MainMenu(Start app) {
        this.app = app;

        this.camera= new OrthographicCamera();
        this.stage = new Stage(new StretchViewport(1100,675,camera));
        camera.setToOrtho(false,1100,675);
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void show() {
        backgroundimg = new Texture("MENU.png");
        Gdx.input.setInputProcessor(stage);
        startimg = new Texture("Large Buttons/Colored Large Buttons/New Game  col_Button.png");
        endimg = new Texture("Large Buttons/Colored Large Buttons/Exit  col_Button.png");
        font = new BitmapFont();
        font.setColor(Color.RED);
        font.getData().setScale(2);
    }



    @Override
    public void render(float delta) {
        ScreenUtils.clear(1, 0, 0, 1);
        camera.update();
        app.batch.begin();
        app.batch.draw(backgroundimg,0,0);
        app.batch.draw(startimg,Gdx.graphics.getWidth()/3+50,Gdx.graphics.getHeight()/3,300,100);
        app.batch.draw(endimg,Gdx.graphics.getWidth()/3,Gdx.graphics.getHeight()/6,300,100);
        stage.draw();
        if(Gdx.input.isKeyPressed(Input.Keys.ENTER)){
            app.setScreen(new pausemenu(app));
        }
        if(Gdx.input.isKeyPressed(Input.Keys.ESCAPE)){
            Gdx.app.exit();
        }
        stage.act();
        app.batch.end();
    }
    private void update(float delta){
        stage.act(delta);
    }
    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        backgroundimg.dispose();
        startimg.dispose();
        app.batch.dispose();
    }
}
