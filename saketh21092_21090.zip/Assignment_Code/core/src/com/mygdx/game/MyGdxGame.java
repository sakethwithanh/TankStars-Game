package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;

public class MyGdxGame implements Screen {
	private final Start app;
	private Stage stage;
	Texture img,tank1;
	OrthographicCamera camera;
	float tank1_x_position,tank1_y_position,tank1_height, tank1_width;
	boolean paused;
	Texture saveimg;
	Texture resumeimg;
	Texture endimg;

	private Skin skin;


	BitmapFont font;

	public MyGdxGame(Start app) {
		this.app = app;
		img = new Texture("background.png");
		tank1 = new Texture("tank.png");
		saveimg = new Texture("Large Buttons/Colored Large Buttons/save.png");
		resumeimg = new Texture("Large Buttons/Colored Large Buttons/Resume  col_Button.png");
		endimg = new Texture("Large Buttons/Colored Large Buttons/Quit  col_Button.png");
		skin = new Skin();
		stage = new Stage();
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 1920, 1080);
		tank1_x_position = Gdx.graphics.getWidth()/3;
		tank1_y_position = Gdx.graphics.getHeight()/7;
		tank1_width = Gdx.graphics.getWidth()/13;
		tank1_height = Gdx.graphics.getHeight()/11;
		font = new BitmapFont();
		font.setColor(Color.RED);
		font.getData().setScale(2);
	}




	public void inputs(){
		if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
			tank1_x_position+=200*Gdx.graphics.getDeltaTime();
		}
		if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
			tank1_x_position-=200*Gdx.graphics.getDeltaTime();
		}
		if(Gdx.input.isKeyPressed(Input.Keys.C)){

		}
		if(tank1_x_position>1200-64){
			tank1_x_position = 1200-64;
		}
		if(tank1_x_position<0){
			tank1_x_position=0;
		}
		if(Gdx.input.isKeyPressed(Input.Keys.P)){
			paused = true;
			try {
				Thread.sleep(100);
			}catch(InterruptedException e){
				e.printStackTrace();
			}
		}
	}

	@Override
	public void show() {
		Gdx.input.setInputProcessor(stage);

	}

	@Override
	public void render(float delta) {
		ScreenUtils.clear(1, 0, 0, 1);

		if(paused){
			if(Gdx.input.isKeyPressed(Input.Keys.P)){
				paused = false;
				try {
					Thread.sleep(100);
				}catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
		else{
			inputs();
		}
		app.batch.begin();
		app.batch.draw(img, 0, 0);
		app.batch.draw(tank1, tank1_x_position,tank1_y_position,tank1_width,tank1_height);
		if(paused){
			if(Gdx.input.isKeyPressed(Input.Keys.ESCAPE)){
				Gdx.app.exit();
			}
			app.font.draw(app.batch,"Paused",30,30);
			app.batch.draw(resumeimg,Gdx.graphics.getWidth()/3+30,Gdx.graphics.getHeight()/3+200,300,100);
			app.batch.draw(saveimg,Gdx.graphics.getWidth()/3+30,Gdx.graphics.getHeight()/3+50,300,100);
			app.batch.draw(endimg,Gdx.graphics.getWidth()/3+30,Gdx.graphics.getHeight()/3-100,300,100);

		}
		app.batch.end();
	}

	@Override
	public void resize(int width, int height) {

	}
	private void update(float delta){
		this.stage = new Stage(new StretchViewport(1920,1080,camera));
		stage.act(delta);

	}
	@Override
	public void pause() {

	}

	@Override
	public void resume() {

	}

	@Override
	public void hide() {

	}

	@Override
	public void dispose () {

		img.dispose();
		stage.dispose();

	}

//	private void initButtons(){
//		buttonPlay = new TextButton("Play",skin,"default");
//		buttonPlay.setPosition(110,260);
//		buttonPlay.setSize(200,60);
//		stage.addActor(buttonPlay);
//	}
}
