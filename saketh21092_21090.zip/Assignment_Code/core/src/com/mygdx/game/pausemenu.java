package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;

public class pausemenu implements Screen {
    private final Start app;
    OrthographicCamera camera;
    Texture backgroundimg;
    private Stage stage;
    Texture tank1;
    Texture tank2;
    Texture tank3;
    Texture tank4;

    BitmapFont font;
    public void create(){
        Gdx.input.setInputProcessor(stage);
    }
    public pausemenu(Start app) {
        this.app = app;

        this.camera= new OrthographicCamera();
        this.stage = new Stage(new StretchViewport(1100,675,camera));
        camera.setToOrtho(false,1100,675);
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void show() {
        backgroundimg = new Texture("MENU.png");
        Gdx.input.setInputProcessor(stage);
        tank1 = new Texture("tank.png");
        tank2 = new Texture("tank3.png");
        tank3 = new Texture("tank1.png");
        tank4 = new Texture("tank4.png");
        font = new BitmapFont();
        font.setColor(Color.RED);
        font.getData().setScale(2);
    }



    @Override
    public void render(float delta) {
        ScreenUtils.clear(1, 0, 0, 1);
        camera.update();
        app.batch.begin();
        app.batch.draw(backgroundimg,0,0);
        app.font.draw(app.batch,"Please use your spacebar to continue",1200/2-100,630);
        app.batch.draw(tank1,Gdx.graphics.getWidth()/3-300,Gdx.graphics.getHeight()/3,Gdx.graphics.getWidth()/13+300,Gdx.graphics.getHeight()/11+300);
        app.batch.draw(tank2,Gdx.graphics.getWidth()/3+300,Gdx.graphics.getHeight()/6,Gdx.graphics.getWidth()/13+600,Gdx.graphics.getWidth()/11+600);
        app.batch.draw(tank3,Gdx.graphics.getWidth()/3-450,Gdx.graphics.getHeight()/6-300,Gdx.graphics.getWidth()/13+700,Gdx.graphics.getWidth()/11+700);
        app.batch.draw(tank4,Gdx.graphics.getWidth()/3+250,Gdx.graphics.getHeight()/6-150,Gdx.graphics.getWidth()/13+400,Gdx.graphics.getWidth()/11+400);
        stage.draw();
        if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
            app.setScreen(new MyGdxGame(app));
        }
        if(Gdx.input.isKeyPressed(Input.Keys.BACKSPACE)){
            app.setScreen(new MainMenu(app));
        }
        stage.act();
        app.batch.end();
    }
    private void update(float delta){
        stage.act(delta);
    }
    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        backgroundimg.dispose();
        tank1.dispose();
        app.batch.dispose();
    }
}
